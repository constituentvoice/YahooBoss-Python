Simple Wrapper Around the Yahoo Boss Search API - https://developer.yahoo.com/boss/search/
